---
title: Function name
tags: array
cover: image
firstSeen: 2021-06-13T05:00:00-04:00
---

Explain briefly what the snippet does.

- Explain briefly how the snippet works.
- Use bullet points for your snippet's explanation.
- Try to explain everything briefly but clearly.

```js
const functionName = arguments =>
  {functionBody}
```

```js
functionName('sampleInput'); // 'sampleOutput'
```
